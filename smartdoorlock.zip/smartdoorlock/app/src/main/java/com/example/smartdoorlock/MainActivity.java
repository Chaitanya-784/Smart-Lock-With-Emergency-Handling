package com.example.smartdoorlock;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_PERMISSION_LOCATION = 100;
    private static final int REQUEST_PERMISSION_BLUETOOTH_CONNECT = 200;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private InputStream bluetoothInputStream;
    private TextView smokeLevelTextView;
    private Handler handler = new Handler();
    private Executor executor;
    private BiometricPrompt biometricPrompt;
    private BiometricPrompt.PromptInfo promptInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton bluetoothButton = findViewById(R.id.btn_bluetooth);
        ImageButton biometricButton = findViewById(R.id.btn_biometric);
        smokeLevelTextView = findViewById(R.id.tvSmokeLevel);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        bluetoothButton.setOnClickListener(v -> {
            if (bluetoothAdapter == null) {
                Toast.makeText(MainActivity.this, "Bluetooth not supported", Toast.LENGTH_SHORT).show();
            } else {
                if (!bluetoothAdapter.isEnabled()) {
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                } else {
                    checkBluetoothPermission();
                }
            }
        });

        executor = Executors.newSingleThreadExecutor();
        biometricPrompt = new BiometricPrompt(MainActivity.this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                unlockDoor();
            }
        });

        promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Biometric Login")
                .setSubtitle("Use your fingerprint to unlock")
                .setNegativeButtonText("Cancel")
                .build();

        biometricButton.setOnClickListener(v -> biometricPrompt.authenticate(promptInfo));
    }

    private void checkBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        REQUEST_PERMISSION_BLUETOOTH_CONNECT
                );
            } else {
                showBluetoothDevices();
            }
        } else {
            showBluetoothDevices();
        }
    }

    private void showBluetoothDevices() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSION_LOCATION);
            return;
        }

        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            ArrayList<String> deviceList = new ArrayList<>();
            for (BluetoothDevice device : pairedDevices) {
                deviceList.add(device.getName() + " [" + device.getAddress() + "]");
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Select a Bluetooth device")
                    .setItems(deviceList.toArray(new CharSequence[0]), (dialog, which) -> {
                        BluetoothDevice selectedDevice = (BluetoothDevice) pairedDevices.toArray()[which];
                        connectToDevice(selectedDevice);
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                    .show();
        } else {
            Toast.makeText(this, "No paired Bluetooth devices found", Toast.LENGTH_SHORT).show();
        }
    }

    private void connectToDevice(BluetoothDevice device) {
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        REQUEST_PERMISSION_BLUETOOTH_CONNECT
                );
                return;
            }
            bluetoothSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();
            bluetoothInputStream = bluetoothSocket.getInputStream();
            Toast.makeText(this, "Connected to " + device.getName(), Toast.LENGTH_SHORT).show();
            readSmokeLevel();
        } catch (IOException e) {
            Toast.makeText(this, "Connection failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void unlockDoor() {
        if (bluetoothSocket != null && bluetoothSocket.isConnected()) {
            try {
                bluetoothSocket.getOutputStream().write("U".getBytes()); // 'U' for unlock
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Unlocking Door...", Toast.LENGTH_SHORT).show());
            } catch (IOException e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Failed to unlock the door", Toast.LENGTH_SHORT).show());
                e.printStackTrace();
            }
        } else {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Bluetooth not connected", Toast.LENGTH_SHORT).show());
        }
    }

    private void readSmokeLevel() {
        handler.post(() -> {
            if (bluetoothInputStream != null) {
                try {
                    byte[] buffer = new byte[256];
                    int bytes;
                    if ((bytes = bluetoothInputStream.read(buffer)) > 0) {
                        String smokeLevel = new String(buffer, 0, bytes).trim();
                        smokeLevelTextView.setText("Smoke Level: " + smokeLevel);
                    }
                } catch (IOException e) {
                    Toast.makeText(MainActivity.this, "Error reading smoke level", Toast.LENGTH_SHORT).show();
                }
                handler.postDelayed(this::readSmokeLevel, 1000);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION_BLUETOOTH_CONNECT) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showBluetoothDevices();
            } else {
                Toast.makeText(this, "Bluetooth permission is required", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (bluetoothSocket != null) bluetoothSocket.close();
        } catch (IOException ignored) {}
    }
}
